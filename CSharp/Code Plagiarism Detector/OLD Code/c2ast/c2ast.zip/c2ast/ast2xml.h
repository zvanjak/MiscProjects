#ifndef _AST2XML_
#define _AST2XML_

#include "stdafx.h"
#include "ast.h"

string ast2xml(const AST &ast);

#endif
